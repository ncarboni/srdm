#! /bin/bash
for file in *.png ; do
	rename 's/.ttl.mmd//' *.png
done

